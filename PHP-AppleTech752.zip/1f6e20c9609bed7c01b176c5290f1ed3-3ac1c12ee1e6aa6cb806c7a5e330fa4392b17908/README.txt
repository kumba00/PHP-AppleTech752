FOLLOW THIS TUTORIAL FIRST!

1. Start PHP server
	
	php -S localhost:7000

2. Activate Device
	
	ideviceactivation activate -s http://localhost:7000/sliver.php